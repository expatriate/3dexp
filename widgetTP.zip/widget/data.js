var widgetv1events = [
  {
    ru: {
      "time": "10:00",
      "name": "Тестовое событие",
      "descr": "Описание тестового события",
      "speaker_img": "speaker1.jpg",
      "speaker": "Петр Иванович Иванов",
      "place_img": "plan1.jpg",
      "place": "Малый зал",
      "founder": "Комиссия по развитию детского и молодежно-технического творчества",
      "theme": {
        "text": "Многостроковый пример текста",
        "list": [
          "один"
          ,
          "два"
          ,
          "три"
          ,
          "четыре"
        ]
      }
    },
    en: {
      "time": "10:00",
      "name": "Test",
      "descr": "Test evend description",
      "speaker_img": "speaker1.jpg",
      "speaker": "Petr Ivanovich Ivanov",
      "place_img": "plan1.jpg",
      "place": "Small place",
      "founder": "Founder",
      "theme": {
        "text": "Multiline sample",
        "list": [
          "One"
          ,
          "Two"
          ,
          "Three"
          ,
          "Four"
        ]
      }
    }
  },{
    ru: {
      "time": "12:00",
      "name": "Тестовое событие",
      "descr": "Описание тестового события",
      "speaker_img": "speaker1.jpg",
      "speaker": "Петр Иванович Иванов",
      "place_img": "plan1.jpg",
      "place": "Малый зал",
      "founder": "Комиссия по развитию детского и молодежно-технического творчества",
      "theme": {
        "text": "Многостроковый пример текста",
        "list": [
          "один"
          ,
          "два"
          ,
          "три"
          ,
          "четыре"
        ]
      }
    },
    en: {
      "time": "12:00",
      "name": "Test",
      "descr": "Test evend description",
      "speaker_img": "speaker1.jpg",
      "speaker": "Petr Ivanovich Ivanov",
      "place_img": "plan1.jpg",
      "place": "Small place",
      "founder": "Founder",
      "theme": {
        "text": "Multiline sample",
        "list": [
          "One"
          ,
          "Two"
          ,
          "Three"
          ,
          "Four"
        ]
      }
    }
  },{
    ru: {
      "time": "16:00",
      "name": "Тестовое событие",
      "descr": "Описание тестового события",
      "speaker_img": "speaker1.jpg",
      "speaker": "Петр Иванович Иванов",
      "place_img": "plan1.jpg",
      "place": "Малый зал",
      "founder": "Комиссия по развитию детского и молодежно-технического творчества",
      "theme": {
        "text": "Многостроковый пример текста",
        "list": [
          "один"
          ,
          "два"
          ,
          "три"
          ,
          "четыре"
        ]
      }
    },
    en: {
      "time": "16:00",
      "name": "Test",
      "descr": "Test evend description",
      "speaker_img": "speaker1.jpg",
      "speaker": "Petr Ivanovich Ivanov",
      "place_img": "plan1.jpg",
      "place": "Small place",
      "founder": "Founder",
      "theme": {
        "text": "Multiline sample",
        "list": [
          "One"
          ,
          "Two"
          ,
          "Three"
          ,
          "Four"
        ]
      }
    }
  },
]